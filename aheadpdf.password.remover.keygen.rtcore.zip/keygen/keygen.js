/*
 *     rtcore
 *
 *  www.rtcore.gq
 **/
 
function Keygen()
{
	this.multiplicator_to_serialpart = function(multiplicator)
	{
		var result = "";

		for (var i = 7-1; i >= 0; i--)
		{
			var foundChar = false;
			for (var c = 'A'.charCodeAt(0); c <= 'Z'.charCodeAt(0); c++)
			{
				if ((multiplicator + 0x41 - c) % 0x1A == 0)
				{
					foundChar = true;
					result = String.fromCharCode(c) + result;
					multiplicator += 0x41 - c;
					multiplicator /= 0x1A;
					break;
				}
			}
			if (!foundChar)
			{
				console.log("Unknown error\n");
				return null;
			}
		}
		
		return result;
	};
	
	this.serialpart_to_multiplicator = function(serialPart, length)
	{
		var result = 0;

		for (var i = 0; i < length; i++)
		{
			result *= 0x1A;
			result += serialPart[i].charCodeAt(0) - 0x41;
		}

		return (result & 0xFFFFFFFF);
	};
	
	this.get_last_char = function(
		serialPart1Prefix, serialPart1,
		serialPart2Prefix, serialPart2, 
		serialPart3Prefix, serialPart3, 
		serialPart4Prefix, serialPart4)
	{
		var sum = 0;

		var serialBuffer = 
			serialPart1Prefix + serialPart1 + 
			serialPart2Prefix + serialPart2 + 
			serialPart3Prefix + serialPart3 + 
			serialPart4Prefix + serialPart4;

		for (var i = 0; i < 0x24; i++)
		{
			sum += this.serialpart_to_multiplicator(serialBuffer[i], 1) * (i + 1);
		}

		return String.fromCharCode( ((sum % 0x1A) + 0x41) & 0xFF );
	};
	
	this.generate_random_string = function(length)
	{
		var result = "";
		
		for(var i = 0; i < length; i++)
		{
			result += String.fromCharCode(Math.floor(Math.random()*26) + 0x41);
		}
		
		return result;
	};
	
	this.generate_serial = function()
	{
		var multiplicator1 = (Math.floor(Math.random()*0xFFFFFFFF) & 0xFFFFFF00) | 0x0B;
		var serialPart1 = this.multiplicator_to_serialpart(multiplicator1);
		while(multiplicator1 != this.serialpart_to_multiplicator(serialPart1, 7))
		{
			multiplicator1 = (Math.floor(Math.random()*0xFFFFFFFF) & 0xFFFFFF00) | 0x0B;
			serialPart1 = this.multiplicator_to_serialpart(multiplicator1);
		}
		
		var serialPart2 = this.generate_random_string(7);
		
		var serialPart4 = this.generate_random_string(7);
		var multiplicator4 = this.serialpart_to_multiplicator(serialPart4, 7);
		while(multiplicator4 != this.serialpart_to_multiplicator(serialPart4, 7))
		{
			serialPart4 = this.generate_random_string(7);
			multiplicator4 = this.serialpart_to_multiplicator(serialPart4, 7);
		}
		
		var multiplicator3 = (Math.floor(Math.random()*0xFFFFFFFF) & 0xFFFFFF00) | ((((multiplicator1 >> 8) & 0xFF) + ((multiplicator1 >> 24) & 0xFF) + (multiplicator4 & 0xFF)) & 0xFF);
		
		var serialPart3 = this.multiplicator_to_serialpart(multiplicator3);
		
		while(multiplicator3 != this.serialpart_to_multiplicator(serialPart3, 7))
		{
			multiplicator3 = (Math.floor(Math.random()*0xFFFFFFFF) & 0xFFFFFF00) | ((((multiplicator1 >> 8) & 0xFF) + ((multiplicator1 >> 24) & 0xFF) + (multiplicator4 & 0xFF)) & 0xFF);
			serialPart3 = this.multiplicator_to_serialpart(multiplicator3);
		}
		
		var serialPart1Prefix = this.generate_random_string(2);
		var serialPart2Prefix = this.generate_random_string(2);
		var serialPart3Prefix = this.generate_random_string(2);
		var serialPart4Prefix = this.generate_random_string(2);
		
		var lastChar = this.get_last_char(
			serialPart1Prefix, serialPart1,
			serialPart2Prefix, serialPart2,
			serialPart3Prefix, serialPart3,
			serialPart4Prefix, serialPart4
		);
		
		return serialPart1Prefix + serialPart1 + "-" +
			serialPart2Prefix + serialPart2 + "-" +
			serialPart3Prefix + serialPart3 + "-" +
			serialPart4Prefix + serialPart4 + lastChar;
	};
}

var keygen = new Keygen();

function copy_serial_to_clipboard()
{
	document.getElementById('copyinput').value = document.getElementById('serial').innerHTML;
	document.getElementById('copyinput').select();
	document.execCommand("Copy");
}

function generate_new_serial()
{
	document.getElementById('serial').innerHTML = keygen.generate_serial();
	document.getElementById('serial').style.color = '#' + Math.floor(Math.random()*0xFFFFFF).toString(16);
}
